package com.facebook.newarchitecture;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.facebook.infer.annotation.Assertions;
import com.facebook.react.*;
import com.facebook.react.bridge.*;
import com.facebook.react.common.LifecycleState;
import com.facebook.react.fabric.ComponentFactory;
import com.facebook.react.fabric.CoreComponentsRegistry;
import com.facebook.react.fabric.FabricJSIModuleProvider;
import com.facebook.react.fabric.ReactNativeConfig;
import com.facebook.react.uimanager.ViewManagerRegistry;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

/**
 * A {@link ReactNativeHost} that helps you load everything needed for the New Architecture, both
 * TurboModule delegates and the Fabric Renderer.
 *
 * <p>Please note that this class is used ONLY if you opt in for the New Architecture (see the
 * `newArchEnabled` property). Is ignored otherwise.
 */
public class BaseReactNativeHost extends ReactNativeHost {

    private static Application app;

    public static void setApplication(Application app) {
        BaseReactNativeHost.app = app;
    }

    private final String jsBundleFile;

    private final boolean debug;

    public BaseReactNativeHost(String jsBundleFile) {
        super(BaseReactNativeHost.app);
        this.jsBundleFile = jsBundleFile;
        debug = jsBundleFile == null || jsBundleFile.isEmpty();
    }

    @Override
    public boolean getUseDeveloperSupport() {
        return debug;
    }

    public static ReactNativeHost getApplicationReactNativeHost() {
        return ((ReactApplication) BaseReactNativeHost.app).getReactNativeHost();
    }

    @Override
    protected ReactInstanceManager createReactInstanceManager() {
        ReactMarker.logMarker(ReactMarkerConstants.BUILD_REACT_INSTANCE_MANAGER_START);
        ReactInstanceManagerBuilder builder = ReactInstanceManager.builder().setApplication(BaseReactNativeHost.app).setJSMainModulePath(this.getJSMainModuleName()).setUseDeveloperSupport(this.getUseDeveloperSupport()).setDevSupportManagerFactory(this.getDevSupportManagerFactory()).setRequireActivity(this.getShouldRequireActivity()).setSurfaceDelegateFactory(this.getSurfaceDelegateFactory()).setLazyViewManagersEnabled(this.getLazyViewManagersEnabled()).setRedBoxHandler(this.getRedBoxHandler()).setJavaScriptExecutorFactory(this.getJavaScriptExecutorFactory()).setUIImplementationProvider(this.getUIImplementationProvider()).setJSIModulesPackage(this.getJSIModulePackage()).setInitialLifecycleState(LifecycleState.BEFORE_CREATE).setReactPackageTurboModuleManagerDelegateBuilder(this.getReactPackageTurboModuleManagerDelegateBuilder());

        for (ReactPackage reactPackage : this.getPackages()) {
            builder.addPackage(reactPackage);
        }

        String jsBundleFile = this.getJSBundleFile();
        if (jsBundleFile != null) {
            builder.setJSBundleFile(jsBundleFile);
        } else {
            builder.setBundleAssetName(Assertions.assertNotNull(this.getBundleAssetName()));
        }

        builder.setJsEngineAsHermes(jsEngineAsHermesEnabled());

        ReactInstanceManager reactInstanceManager = builder.build();
        ReactMarker.logMarker(ReactMarkerConstants.BUILD_REACT_INSTANCE_MANAGER_END);
        return reactInstanceManager;
    }

    protected void addReactPackage(final List<ReactPackage> packages) {

    }

    protected boolean jsEngineAsHermesEnabled() {
        return true;
    }

    @Override
    protected List<ReactPackage> getPackages() {
        List<ReactPackage> packages = null;
        try {
            Class<?> aClass = Class.forName("com.facebook.react.PackageList");
            Object o = aClass.getDeclaredConstructor(new Class[]{ReactNativeHost.class}).newInstance(this);
            packages = (List<ReactPackage>) aClass.getMethod("getPackages").invoke(o);
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException | NoSuchMethodException |
                 InvocationTargetException e) {
            packages = new ArrayList<>();
        }
//    List<ReactPackage> packages = new PackageList(this).getPackages();
        // Packages that cannot be autolinked yet can be added manually here, for example:
        //     packages.add(new MyReactNativePackage());
        // TurboModules must also be loaded here providing a valid TurboReactPackage implementation:
        //     packages.add(new TurboReactPackage() { ... });
        // If you have custom Fabric Components, their ViewManagers should also be loaded here
        // inside a ReactPackage.
        if (packages != null) {
            addReactPackage(packages);
        }
        return packages;
    }

    @Override
    protected String getJSMainModuleName() {
        return "index";
    }

    @Nullable
    @Override
    protected String getJSBundleFile() {
        return jsBundleFile;
    }

    @NonNull
    @Override
    protected ReactPackageTurboModuleManagerDelegate.Builder
    getReactPackageTurboModuleManagerDelegateBuilder() {
        // Here we provide the ReactPackageTurboModuleManagerDelegate Builder. This is necessary
        // for the new architecture and to use TurboModules correctly.
        return new ReactPackageTurboModuleManagerDelegate.Builder() {
            @Override
            protected ReactPackageTurboModuleManagerDelegate build(ReactApplicationContext reactApplicationContext, List<ReactPackage> list) {
                try {
                    Class<?> aClass = Class.forName("com.facebook.newarchitecture.modules.MainApplicationTurboModuleManagerDelegate");
                    return (ReactPackageTurboModuleManagerDelegate) aClass.getDeclaredConstructor(new Class[]{ReactApplicationContext.class, List.class}).newInstance(reactApplicationContext, list);
                } catch (ClassNotFoundException | IllegalAccessException | InstantiationException |
                         NoSuchMethodException | InvocationTargetException e) {
                    return null;
                }
            }
        };
//    return new MainApplicationTurboModuleManagerDelegate.Builder();
    }

    @Override
    protected JSIModulePackage getJSIModulePackage() {
        return new JSIModulePackage() {
            @Override
            public List<JSIModuleSpec> getJSIModules(
                    final ReactApplicationContext reactApplicationContext,
                    final JavaScriptContextHolder jsContext) {
                final List<JSIModuleSpec> specs = new ArrayList<>();

                // Here we provide a new JSIModuleSpec that will be responsible for providing the
                // custom Fabric Components.
                specs.add(
                        new JSIModuleSpec() {
                            @Override
                            public JSIModuleType getJSIModuleType() {
                                return JSIModuleType.UIManager;
                            }

                            @Override
                            public JSIModuleProvider<UIManager> getJSIModuleProvider() {
                                final ComponentFactory componentFactory = new ComponentFactory();
                                CoreComponentsRegistry.register(componentFactory);

                                // Here we register a Components Registry.
                                // The one that is generated with the template contains no components
                                // and just provides you the one from React Native core.

                                try {
                                    Class<?> aClass = Class.forName("com.facebook.newarchitecture.components.MainComponentsRegistry");
                                    aClass
                                            .getMethod("register", ComponentFactory.class)
                                            .invoke(null, componentFactory);
                                } catch (ClassNotFoundException | NoSuchMethodException | IllegalAccessException |
                                         InvocationTargetException e) {
                                    e.printStackTrace();
                                }
//                MainComponentsRegistry.register(componentFactory);

                                final ReactInstanceManager reactInstanceManager = getReactInstanceManager();

                                ViewManagerRegistry viewManagerRegistry =
                                        new ViewManagerRegistry(
                                                reactInstanceManager.getOrCreateViewManagers(reactApplicationContext));

                                return new FabricJSIModuleProvider(
                                        reactApplicationContext,
                                        componentFactory,
                                        ReactNativeConfig.DEFAULT_CONFIG,
                                        viewManagerRegistry);
                            }
                        });
                return specs;
            }
        };
    }
}
